from django.contrib import admin
from .models import Participants


admin.site.register(Participants)